library(testthat)
library(HPAStainR)

test_check("HPAStainR")
