Changes in Version 0.99.5 (2020-07-15)
+ Package prepared for submission to Bioconducctor